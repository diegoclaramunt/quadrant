# `@five/voice-runtime`

Runtime headless para dotar de voz a aplicaciones existentes. El paquete contiene el contrato y el coordinador comunes, pero cada host conserva sus operaciones, reglas de negocio y UX.

## Instalación

Desde un paquete local generado por el repositorio fuente:

```bash
npm run runtime:pack
npm install ./vendor/five-voice-runtime-0.1.1.tgz
```

Las aplicaciones consumidoras pueden fijar el `.tgz` en `vendor/`. El origen único del código del paquete es `packages/voice-runtime`; las copias vendorizadas son artefactos de distribución.

## Entradas públicas

- `@five/voice-runtime/core`: `OperationRegistry`, `OperationManifest`, `ActionController` y `createToolSurface`.
- `@five/voice-runtime/browser`: `BrowserRealtimeSession` y sus tipos de eventos.
- `@five/voice-runtime/server`: handlers para SDP y client secrets de OpenAI Realtime.

El manifiesto público es serializable y solo contiene nombre, tipo, descripción, permisos, schemas JSON y disponibilidad. Las funciones `execute` y el estado del host nunca se publican.

## Contrato de una aplicación

En el ejemplo, `lighting`, `application`, `applicationContext` y `ux` son servicios del host.

La aplicación registra schemas Zod adaptados al contrato `OperationSchema`, que conserva `safeParse` para validar entradas y genera JSON Schema al publicar el manifiesto:

```ts
import { z } from "zod";
import { OperationRegistry, createToolSurface } from "@five/voice-runtime/core";

const lightInput = z.object({
  type: z.literal("light.set"),
  on: z.boolean(),
}).strict();

const schema = {
  safeParse: (value: unknown) => lightInput.safeParse(value),
  toJSONSchema: () => z.toJSONSchema(lightInput, { target: "draft-7" }),
};

const registry = new OperationRegistry();
registry.register({
  name: "light.set",
  kind: "action",
  description: "Enciende o apaga la luz",
  access: "write",
  exposure: "public",
  inputSchema: schema,
  execute: (input) => lighting.setLight(input.on),
});

const manifest = registry.describe(applicationContext);
const surface = createToolSurface(manifest, {
  discriminator: "type",
  requestRevision: true,
});
```

El host decide si una operación está disponible y ejecuta sus reglas de negocio. `createToolSurface` genera nombres cualificados como `action_light_set` y devuelve la operación resuelta junto con la revisión observada; no elimina argumentos desconocidos silenciosamente.

## Coordinación y UX

`ActionController` recibe hooks del host: `validate`, `run`, `result`, `failure` y `getRevision`. También permite `onAccepted`, `onSettled` e `isDisposed`. El runtime aporta serialización, deduplicación por petición, cancelación de sesión, revisiones obsoletas, cola y checkpoints; el host decide efectos, permisos y presentación.

La UX se implementa fuera del paquete. El host escucha los eventos de `BrowserRealtimeSession` (`state`, `activity`, transcripciones, solicitudes/resultados de tools y errores) y decide cómo representar micrófono, conversación, accesibilidad, historial y mensajes. La sesión ejecuta las tools mediante el callback `executeTool` suministrado por la aplicación:

```ts
import { BrowserRealtimeSession } from "@five/voice-runtime/browser";

const session = new BrowserRealtimeSession({
  bootstrap: { mode: "sdp", endpoint: "/api/realtime/call", tools: surface.tools },
  executeTool: async ({ callId, name, arguments: args, sessionId }) => {
    const resolved = surface.resolve(name, args);
    const parsed = registry.validate(resolved.operation.name, resolved.input);
    if (!parsed.success) return { status: "rejected", error: "Parámetros inválidos" };
    return application.execute(parsed.data, {
      requestId: callId,
      sessionId,
      origin: "conversational",
      expectedContextRevision: resolved.expectedContextRevision,
    });
  },
});

session.on("transcript.user", ({ text }) => ux.showUserText(text));
session.on("transcript.assistant", ({ text }) => ux.showAssistantText(text));
await session.start();
```

## Servidor y credenciales

El host server-side usa `createRealtimeSdpHandler` o `createRealtimeClientSecret` de `/server`. Se debe inyectar `getApiKey`, que lee `OPENAI_API_KEY` en el entorno servidor, además de `getTools` y `buildInstructions`. El navegador nunca recibe la API key. El handler restringe método, content type, origen y tamaño de la petición, y no confía en tools enviadas por el cliente.

El runtime no crea autenticación remota, perfiles, persistencia ni autorización de negocio. El host debe proteger su endpoint, resolver identidad y sesión, aplicar CORS/orígenes y decidir qué operaciones puede ejecutar cada usuario.

La dependencia no valida audio real por sí sola: la aplicación debe configurar credenciales, micrófono, endpoint y proveedor Realtime según su entorno.

Para Edge/Deno, la consola genera los archivos de distribución con `npm run runtime:vendor` desde el paquete instalado. Los JS incluyen [referencias a sus declaraciones TypeScript](https://docs.deno.com/runtime/fundamentals/typescript/) y la función declara su [import map](https://supabase.com/docs/guides/functions/function-configuration). No se importan fuentes hermanas durante el despliegue.
